﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace EDITORDETEXTOFORMS
{
    public partial class Form1 : Form
    {
        //String path = "";
        //string archivo;
        #region fields
        private bool isFileAlreadySave;
        private bool isFileDirty;
        private string currentOpenFileName;
        private FontDialog fontdialog = new FontDialog();  //format ma fontcolor ko apply krny k lye
        #endregion
        public Form1()
        {
            InitializeComponent();
        }

        //private string file = "";
        
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfiledialog = new OpenFileDialog();
            openfiledialog.Filter = "Text Files (*.txt)|*.txt|Rich Text Format (*.rtf)|*.rtf|MSWord Files (*.docx)|*.docx|PHP (*.php)|*.php";

            DialogResult result = openfiledialog.ShowDialog();

            if (result == DialogResult.OK)
            {
                if (Path.GetExtension(openfiledialog.FileName) == ".txt")

                    richTextBox1.LoadFile(openfiledialog.FileName, RichTextBoxStreamType.PlainText);
                /*
                if (Path.GetExtension(openfiledialog.FileName) == ".php")
                    richTextBox1.LoadFile(openfiledialog.FileName, RichTextBoxStreamType.PlainText);
                */

                if (Path.GetExtension(openfiledialog.FileName) == ".rtf")
                    richTextBox1.LoadFile(openfiledialog.FileName, RichTextBoxStreamType.RichText);

                this.Text = Path.GetFileName(openfiledialog.FileName) + " - Editor de texto";
                
                isFileAlreadySave = true;
                isFileDirty = false;
                currentOpenFileName = openfiledialog.FileName;
            }

        }

        private void atras_Click(object sender, EventArgs e)
        {
            //atras
            richTextBox1.Undo();
        }

        private void adelante_Click(object sender, EventArgs e)
        {
            //adelante
            richTextBox1.Redo();
        }

        private void fuenteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog font = new FontDialog();
            font.Font = richTextBox1.Font;        
            if (font.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.SelectionFont = font.Font;
            }
        }

        private void colorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //color
            ColorDialog color = new ColorDialog();
            if (color.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.SelectionColor = color.Color;
            }
        }

        private void fondoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog fondo = new ColorDialog();
            if (fondo.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.BackColor = fondo.Color;
            }
        }

        private void guardarcomo_Click(object sender, EventArgs e)
        {
            SaveFileDialog savefiledialog = new SaveFileDialog();
            savefiledialog.Filter = "Text Files (*.txt)|*.txt|Rich Text Format (*.rtf)|*.rtf|MSWord Files (*.docx)|*.docx|PHP (*.php)|*.php";
            DialogResult result = savefiledialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                
                if (Path.GetExtension(savefiledialog.FileName) == ".txt")
                    richTextBox1.SaveFile(savefiledialog.FileName, RichTextBoxStreamType.PlainText);

                if (Path.GetExtension(savefiledialog.FileName) == ".rtf")
                    richTextBox1.SaveFile(savefiledialog.FileName, RichTextBoxStreamType.RichText);


                this.Text = Path.GetFileName(savefiledialog.FileName) + " -Archivo";

                isFileAlreadySave = true;
                isFileDirty = false;
                currentOpenFileName = savefiledialog.FileName;
                
            }

        }

        private void guardar_Click(object sender, EventArgs e)
        {
            guardarsave();
        }
        private void guardarsave()
        {
            if (isFileAlreadySave)
            {

                if (Path.GetExtension(currentOpenFileName) == ".txt")
                    richTextBox1.SaveFile(currentOpenFileName, RichTextBoxStreamType.PlainText);

                /*
                if (Path.GetExtension(currentOpenFileName) == ".php")
                    richTextBox1.SaveFile(currentOpenFileName, RichTextBoxStreamType.PlainText);
                */

                if (Path.GetExtension(currentOpenFileName) == ".rtf")
                    richTextBox1.SaveFile(currentOpenFileName, RichTextBoxStreamType.RichText);
                isFileDirty = false;
            }
            else
            {

                if (isFileDirty)
                {
                    SaveFileDialog savefiledialog = new SaveFileDialog();
                    savefiledialog.Filter = "Text Files (*.txt)|*.txt|Rich Text Format (*.rtf)|*.rtf|MSWord Files (*.docx)|*.docx|PHP (*.php)|*.php";
                    DialogResult result = savefiledialog.ShowDialog();
                    if (result == DialogResult.OK)
                    {

                        if (Path.GetExtension(savefiledialog.FileName) == ".txt")
                            richTextBox1.SaveFile(savefiledialog.FileName, RichTextBoxStreamType.PlainText);

                        if (Path.GetExtension(savefiledialog.FileName) == ".rtf")
                            richTextBox1.SaveFile(savefiledialog.FileName, RichTextBoxStreamType.RichText);


                        this.Text = Path.GetFileName(savefiledialog.FileName) + " -Archivo";


                        isFileAlreadySave = true;
                        isFileDirty = false;
                        currentOpenFileName = savefiledialog.FileName;

                    }
                }
                else
                {
                    clearScreen();
                }

            }
        }
        private void clearScreen()
        {
            richTextBox1.Clear(); 
            this.Text = "Untitled - Archivo";
            isFileDirty = false;
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            if (isFileDirty)
            {
                DialogResult result = MessageBox.Show("Desea guardar los cambios? ", "File Save", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
                switch (result)
                {
                    case DialogResult.Yes:
                        guardarsave();
                        break;

                    case DialogResult.No:

                        break;
                    case DialogResult.Cancel:
                        MessageBox.Show("Operacion cancelada ", "New file", MessageBoxButtons.OK);
                        break;

                }

            }

            clearScreen();
            isFileAlreadySave = false;
            currentOpenFileName = "";
        }




        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            
            ColorDialog color = new ColorDialog();
            if (color.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.SelectionColor = color.Color;
            }
        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            
        }

        private void toolStripButton8_Click(object sender, EventArgs e)
        {
          
        }

        private void toolStripButton9_Click(object sender, EventArgs e)
        {
            
        }

        private void toolStripButton10_Click(object sender, EventArgs e)
        {
           
        }


        private void toolStripButton11_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectedText = DateTime.Now.ToString();
        }
        

        private void toolStripButton12_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Images |*.bmp;*.jpg;*.png;*.gif;*.ico";
            openFileDialog1.Multiselect = false;
            openFileDialog1.FileName = "";
            DialogResult result = openFileDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                Image img = Image.FromFile(openFileDialog1.FileName);
                Clipboard.SetImage(img);
                richTextBox1.Paste();
                richTextBox1.Focus();
            }
            else
            {
                richTextBox1.Focus();
            }
        }

        private void toolStripButton13_Click(object sender, EventArgs e)
        {
           

        }

        private void cortarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richTextBox1.SelectionLength > 0)
            {
                Clipboard.SetText(richTextBox1.SelectedText);
                richTextBox1.SelectedText = "";

            }
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //richTextBox1
            if (richTextBox1.SelectionLength > 0)
                richTextBox1.Copy();
        }

        private void pegarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Clipboard.ContainsText())
            {
                richTextBox1.SelectedText = Clipboard.GetText();
            }
        }

        private void seleccionarTodoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectAll();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void acercaDeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("A little text editor, by Sebastian Quispe", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void abrirr_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfiledialog = new OpenFileDialog();
            openfiledialog.Filter = "Text Files (*.txt)|*.txt|Rich Text Format (*.rtf)|*.rtf|MSWord Files (*.docx)|*.docx|PHP (*.php)|*.php";

            DialogResult result = openfiledialog.ShowDialog();

            if (result == DialogResult.OK)
            {
                if (Path.GetExtension(openfiledialog.FileName) == ".txt")

                    richTextBox1.LoadFile(openfiledialog.FileName, RichTextBoxStreamType.PlainText);
                /*
                if (Path.GetExtension(openfiledialog.FileName) == ".php")
                    richTextBox1.LoadFile(openfiledialog.FileName, RichTextBoxStreamType.PlainText);
                */

                if (Path.GetExtension(openfiledialog.FileName) == ".rtf")
                    richTextBox1.LoadFile(openfiledialog.FileName, RichTextBoxStreamType.RichText);

                this.Text = Path.GetFileName(openfiledialog.FileName) + " - Editor de texto";
                
                isFileAlreadySave = true;
                isFileDirty = false;
                currentOpenFileName = openfiledialog.FileName;



            }
        }

        private void guardarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            guardarsave();
        }

        private void guardarComoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog savefiledialog = new SaveFileDialog();
            savefiledialog.Filter = "Text Files (*.txt)|*.txt|Rich Text Format (*.rtf)|*.rtf|MSWord Files (*.docx)|*.docx|PHP (*.php)|*.php";
            DialogResult result = savefiledialog.ShowDialog();
            if (result == DialogResult.OK)
            {

                if (Path.GetExtension(savefiledialog.FileName) == ".txt")
                    richTextBox1.SaveFile(savefiledialog.FileName, RichTextBoxStreamType.PlainText);

                if (Path.GetExtension(savefiledialog.FileName) == ".rtf")
                    richTextBox1.SaveFile(savefiledialog.FileName, RichTextBoxStreamType.RichText);


                this.Text = Path.GetFileName(savefiledialog.FileName) + " -Archivo";

                isFileAlreadySave = true;
                isFileDirty = false;
                currentOpenFileName = savefiledialog.FileName;

            }
        }
    }
}
