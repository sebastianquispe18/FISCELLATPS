﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json.Linq;

namespace Servcicio_Post_DarkSky
{
    public partial class Form1 : Form
    {
        /* 
        https://docs.microsoft.com/en-us/troubleshoot/iis/make-get-request
        https://www.youtube.com/watch?v=ryz3Q_xsmPI
        */
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string sURL;
            WebRequest wrGETURL;
            JObject json;
            Stream objStream;

            sURL = "https://api.darksky.net/forecast/b4497c8a6b18bf75776b7fd997f2b90a/-34.6119666,-58.4030375?lang=es&units=ca";
            wrGETURL = WebRequest.Create(sURL);
            objStream = wrGETURL.GetResponse().GetResponseStream();
            StreamReader objReader = new StreamReader(objStream);

            string sLine = "";
            string sLinePrev = "";
            int i = 0;

            while (sLine != null)
            {
                i++;
                sLinePrev = sLine;
                sLine = objReader.ReadLine();
            }
            
            
            json = JObject.Parse(sLinePrev);
            
            //(hoy)
            this.label3.Text = (json["daily"]["data"][0]["icon"].ToString());
            this.label4.Text = (json["daily"]["data"][0]["temperatureMax"] + "°");
            this.label5.Text = (json["daily"]["data"][0]["temperatureMin"] + "°");
            this.label6.Text = (json["daily"]["data"][0]["precipProbability"] + "%");
            this.label13.Text = (json["daily"]["data"][0]["humidity"] + "%");

            //ahora
            this.label15.Text = json["currently"]["icon"].ToString();
            this.label16.Text = json["currently"]["temperature"] + "°".ToString();
            pictureBox5.Image = Image.FromFile("imagenes/" + json["currently"]["icon"] + ".png");


            //separacion de hoy y mañana
           

            //(mañana)
            this.label7.Text = (json["daily"]["data"][1]["icon"].ToString());
            this.label8.Text = (json["daily"]["data"][1]["temperatureMax"] + "°");
            this.label9.Text = (json["daily"]["data"][1]["temperatureMin"] + "°");
            this.label10.Text = (json["daily"]["data"][1]["precipProbability"] + "%");
            this.label14.Text = (json["daily"]["data"][1]["humidity"] + "%");


            //lat.long
            //this.label2.Text = (json["timezone"]+ ".");
            this.label26.Text = (json["latitude"].ToString());
            this.label27.Text = (json["longitude"].ToString());



            string[] lugar;
            lugar =json["timezone"].ToString().Split('/');

            if (lugar.Length == 3)
            {
                if(lugar[2].Split('_').Length == 1)
                {
                    label2.Text = lugar[0] + " " + lugar[1] + " " + lugar[2];
                }                    
                else
                {
                    //string[] ciudad = lugar[2].Split('_');
                    //label2.Text = lugar[0] + " " + lugar[1] + " " + ciudad[0] + ", " + ciudad[1];
                    label2.Text = lugar[0] + " " + lugar[1] + ", " + lugar[2].Split('_')[0] + " " + lugar[2].Split('_')[1];
                }
            }                
            else
            {
                label2.Text = lugar[0] + " " + lugar[1];
            }
       
            //MessageBox.Show(lugar[0]);
            //MessageBox.Show(lugar[1]);
            //MessageBox.Show(lugar[2]);
            //lugar = this.label2.Text = (json["timezone"].ToString().Split('/') + ".");
            pictureBox2.Image = Image.FromFile("imagenes/" + json["daily"]["data"][1]["icon"] + ".png");
            pictureBox1.Image = Image.FromFile("imagenes/" + json["daily"]["data"][0]["icon"] + ".png");


            timer1.Enabled = true;

            pictureBox3.Image = Image.FromFile("imagencomplemento/mundopro.gif");
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;

            pictureBox4.Image = Image.FromFile("imagencomplemento/ojos3.gif");
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;

            pictureBox6.Image = Image.FromFile("imagencomplemento/DECOR.gif");
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        
        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToString("hh:mm:ss");
            label25.Text = DateTime.Now.ToLongDateString();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Application.Restart();
        }

    }
}
